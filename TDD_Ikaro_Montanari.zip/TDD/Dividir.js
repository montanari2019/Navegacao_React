export default function Dividir(a , b){
    // console.log(a / b)
    return a / b
}