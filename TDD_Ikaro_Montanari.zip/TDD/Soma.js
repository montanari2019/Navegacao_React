export default function Soma(a, b){
    return a + b
}