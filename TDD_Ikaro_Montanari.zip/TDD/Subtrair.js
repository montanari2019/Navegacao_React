export default function Subtrair(a , b){
    return a - b
}