export default function Multiplicar(a, b){
    console.log('Multiplicação de = ' + a * b)
    return a * b
}